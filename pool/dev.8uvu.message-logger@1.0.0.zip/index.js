(() => { const module = { exports: {} }; const exports = module.exports; var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// D:/Revenge plugins/message-logger/js/index.tsx
var index_exports = {};
__export(index_exports, {
  default: () => index_default
});
module.exports = __toCommonJS(index_exports);
var import_react = (({ default: revenge.react.React, ...revenge.react.React }));
var import_react_native = (({ ...revenge.react.ReactNative }));
var import_design = (revenge.discord.design);
var import_flux = (revenge.discord.flux);
var import_native = (revenge.discord.native);
var import_jsx_runtime = (({ jsx: revenge.react.ReactJSXRuntime.jsx, jsxs: revenge.react.ReactJSXRuntime.jsxs, Fragment: revenge.react.ReactJSXRuntime.Fragment }));
var LOG_FILE = "message-logger/logs.json";
var log = {};
var logDir = "";
var flushTimer = null;
var apiRef = null;
function logPath() {
  return logDir + "/" + LOG_FILE;
}
async function loadLog(logger) {
  var _a;
  try {
    logDir = import_native.FileModule.getConstants().DocumentsDirPath;
    const raw = await import_native.FileModule.readFile(logPath(), "utf8");
    const parsed = JSON.parse(raw);
    if (parsed && typeof parsed === "object") log = parsed;
  } catch (e) {
    log = {};
    (_a = logger == null ? void 0 : logger.log) == null ? void 0 : _a.call(logger, "MessageLogger: starting with an empty log");
  }
}
async function persistLog() {
  var _a, _b;
  try {
    await import_native.FileModule.writeFile("documents", LOG_FILE, JSON.stringify(log), "utf8");
  } catch (e) {
    (_b = (_a = apiRef == null ? void 0 : apiRef.logger) == null ? void 0 : _a.error) == null ? void 0 : _b.call(_a, "MessageLogger: failed to write log file");
  }
}
function prune(max) {
  const ids = Object.keys(log);
  if (ids.length <= max) return;
  ids.map((id) => log[id]).sort((a, b) => a.timestamp - b.timestamp).slice(0, ids.length - max).forEach((m) => {
    delete log[m.id];
  });
}
function ignoredChannel(channelId, raw) {
  if (!raw) return false;
  const list = raw.split(/[\s,]+/).map((s) => s.trim()).filter(Boolean);
  return list.includes(String(channelId));
}
function snapshotOf(message) {
  var _a, _b, _c, _d, _e, _f;
  const author = (_a = message == null ? void 0 : message.author) != null ? _a : {};
  return {
    id: String((_b = message == null ? void 0 : message.id) != null ? _b : ""),
    channelId: String((_d = (_c = message == null ? void 0 : message.channelId) != null ? _c : message == null ? void 0 : message.channel_id) != null ? _d : ""),
    authorId: String((_e = author == null ? void 0 : author.id) != null ? _e : ""),
    authorTag: (author == null ? void 0 : author.globalName) || (author == null ? void 0 : author.username) || "Unknown",
    content: String((_f = message == null ? void 0 : message.content) != null ? _f : ""),
    attachments: Array.isArray(message == null ? void 0 : message.attachments) ? message.attachments.map((a) => {
      var _a2, _b2;
      return String((_b2 = (_a2 = a == null ? void 0 : a.url) != null ? _a2 : a == null ? void 0 : a.proxy_url) != null ? _b2 : "");
    }).filter(Boolean).slice(0, 3) : [],
    timestamp: Date.parse(message == null ? void 0 : message.timestamp) || Date.now()
  };
}
var seen = /* @__PURE__ */ new Map();
function handleCreate(payload, cfg) {
  var _a, _b;
  const message = payload == null ? void 0 : payload.message;
  if (!(message == null ? void 0 : message.id)) return;
  if (!cfg.enabled || ignoredChannel(String((_b = (_a = message.channelId) != null ? _a : message.channel_id) != null ? _b : ""), cfg.ignoredChannels)) return;
  seen.set(String(message.id), snapshotOf(message));
  if (seen.size > cfg.maxStored * 4) {
    const first = seen.keys().next();
    if (!first.done) seen.delete(first.value);
  }
}
function handleDelete(payload, cfg) {
  var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j;
  if (!cfg.enabled || !cfg.logDeletes) return;
  const id = String((_c = (_b = (_a = payload == null ? void 0 : payload.message) == null ? void 0 : _a.id) != null ? _b : payload == null ? void 0 : payload.id) != null ? _c : "");
  const channelId = String((_f = (_e = (_d = payload == null ? void 0 : payload.message) == null ? void 0 : _d.channelId) != null ? _e : payload == null ? void 0 : payload.channelId) != null ? _f : "");
  if (!id || ignoredChannel(channelId, cfg.ignoredChannels)) return;
  const snap = (_h = seen.get(id)) != null ? _h : snapshotOf((_g = payload == null ? void 0 : payload.message) != null ? _g : { id, channelId });
  seen.delete(id);
  log[id] = { ...snap, status: "deleted", edits: (_j = (_i = log[id]) == null ? void 0 : _i.edits) != null ? _j : [] };
  prune(cfg.maxStored);
  persistLog();
}
function handleUpdate(payload, cfg) {
  var _a, _b, _c;
  if (!cfg.enabled || !cfg.logEdits) return;
  const message = payload == null ? void 0 : payload.message;
  if (!(message == null ? void 0 : message.id)) return;
  const id = String(message.id);
  const channelId = String((_b = (_a = message.channelId) != null ? _a : message.channel_id) != null ? _b : "");
  if (ignoredChannel(channelId, cfg.ignoredChannels)) return;
  const prev = seen.get(id);
  const snap = snapshotOf(message);
  seen.set(id, snap);
  const oldContent = prev && prev.content !== snap.content ? prev.content : null;
  const existing = log[id];
  log[id] = {
    ...snap,
    status: "edited",
    edits: [...(_c = existing == null ? void 0 : existing.edits) != null ? _c : [], ...oldContent ? [oldContent] : []].slice(-10)
  };
  prune(cfg.maxStored);
  persistLog();
}
function readCfg(jsonStorage) {
  var _a, _b, _c, _d;
  const c = (_a = jsonStorage == null ? void 0 : jsonStorage.cache) != null ? _a : {};
  return {
    enabled: (_b = c.enabled) != null ? _b : true,
    logDeletes: (_c = c.logDeletes) != null ? _c : true,
    logEdits: (_d = c.logEdits) != null ? _d : true,
    maxStored: typeof c.maxStored === "number" ? c.maxStored : 300,
    ignoredChannels: typeof c.ignoredChannels === "string" ? c.ignoredChannels : ""
  };
}
var index_default = plugin({
  jsonStorage: {
    load: true,
    default: {
      enabled: true,
      logDeletes: true,
      logEdits: true,
      maxStored: 300,
      ignoredChannels: ""
    }
  },
  async start({ cleanup, jsonStorage, logger }) {
    apiRef = { logger };
    await loadLog(logger);
    cleanup(
      (0, import_flux.onFluxEventDispatched)("MESSAGE_CREATE", (payload) => {
        try {
          handleCreate(payload, readCfg(jsonStorage));
        } catch (e) {
          logger.error("create handler failed");
        }
        return payload;
      }),
      (0, import_flux.onFluxEventDispatched)("MESSAGE_DELETE", (payload) => {
        try {
          handleDelete(payload, readCfg(jsonStorage));
        } catch (e) {
          logger.error("delete handler failed");
        }
        return payload;
      }),
      (0, import_flux.onFluxEventDispatched)("MESSAGE_UPDATE", (payload) => {
        try {
          handleUpdate(payload, readCfg(jsonStorage));
        } catch (e) {
          logger.error("update handler failed");
        }
        return payload;
      }),
      () => {
        if (flushTimer) {
          clearTimeout(flushTimer);
          flushTimer = null;
        }
        persistLog();
        seen.clear();
        apiRef = null;
      }
    );
    logger.log("MessageLogger started");
  },
  SettingsComponent({ api }) {
    var _a, _b, _c;
    const settings = api.jsonStorage.use();
    const [entries, setEntries] = (0, import_react.useState)([]);
    const [refreshTick, setRefreshTick] = (0, import_react.useState)(0);
    (0, import_react.useEffect)(() => {
      let alive = true;
      import_native.FileModule.readFile(logPath(), "utf8").then((raw) => {
        if (!alive) return;
        try {
          const parsed = JSON.parse(raw);
          const list = Object.values(parsed != null ? parsed : {});
          list.sort((a, b) => b.timestamp - a.timestamp);
          setEntries(list.slice(0, 50));
        } catch {
          setEntries([]);
        }
      }).catch(() => {
        if (alive) setEntries([]);
      });
      return () => {
        alive = false;
      };
    }, [refreshTick]);
    const { TableRowGroup, TableSwitchRow, Text: DText } = import_design.Design;
    const clearLog = async () => {
      log = {};
      await persistLog();
      setRefreshTick((t) => t + 1);
    };
    return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_react_native.View, { children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TableRowGroup, { title: "MessageLogger", children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
          TableSwitchRow,
          {
            label: "Enabled",
            value: (_a = settings == null ? void 0 : settings.enabled) != null ? _a : true,
            onValueChange: (v) => api.jsonStorage.set({ enabled: v })
          }
        ),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
          TableSwitchRow,
          {
            label: "Log deleted messages",
            value: (_b = settings == null ? void 0 : settings.logDeletes) != null ? _b : true,
            onValueChange: (v) => api.jsonStorage.set({ logDeletes: v })
          }
        ),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
          TableSwitchRow,
          {
            label: "Log edited messages",
            value: (_c = settings == null ? void 0 : settings.logEdits) != null ? _c : true,
            onValueChange: (v) => api.jsonStorage.set({ logEdits: v })
          }
        )
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TableRowGroup, { title: `Saved log (${entries.length} newest shown)`, children: entries.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DText, { children: "Nothing logged yet. Deleted and edited messages will appear here." }) : entries.map((m) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_react_native.View, { style: { paddingVertical: 6 }, children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DText, { children: [
          "[",
          m.status === "deleted" ? "DELETED" : "EDITED",
          "] ",
          m.authorTag,
          " \u2014 ",
          new Date(m.timestamp).toLocaleString()
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DText, { children: m.content || "(no text content)" }),
        m.edits.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DText, { children: [
          "Previous versions: ",
          m.edits.join("  |  ")
        ] })
      ] }, m.id)) }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_react_native.View, { style: { padding: 12 }, children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
          import_react_native.Pressable,
          {
            onPress: () => {
              clearLog();
              setRefreshTick((t) => t + 1);
            },
            style: { padding: 12, borderRadius: 8, alignItems: "center" },
            children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_react_native.Text, { style: { fontWeight: "bold" }, children: "Clear saved log" })
          }
        ),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_react_native.Pressable, { onPress: () => setRefreshTick((t) => t + 1), style: { padding: 12, alignItems: "center" }, children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_react_native.Text, { children: "Refresh list" }) })
      ] })
    ] });
  }
});
; return (module.exports && module.exports.default) || module.exports; })()